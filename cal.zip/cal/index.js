

function add(){
let n1= document.getElementById("num1").value;
let n2= document.getElementById("num2").value;
let r=parseInt(n1)+parseInt(n2)
document.getElementById("result").value=r;

document.getElementById("num1").style.backgroundColor="lightgrey"
document.getElementById("num2").style.backgroundColor="lightgrey"
document.getElementById("result").style.backgroundColor="lightgrey"
}
document.getElementById("add").addEventListener("click",add);




function sub(){
    let n1= document.getElementById("num1").value;
    let n2= document.getElementById("num2").value;
    let r=parseInt(n1)-parseInt(n2)
    document.getElementById("result").value=r;
    
    document.getElementById("num1").style.backgroundColor="pink"
    document.getElementById("num2").style.backgroundColor="pink"
    document.getElementById("result").style.backgroundColor="pink"
    }
    document.getElementById("sub").addEventListener("click",sub);



    
function mul(){
    let n1= document.getElementById("num1").value;
    let n2= document.getElementById("num2").value;
    let r=parseInt(n1)*parseInt(n2)
    document.getElementById("result").value=r;
    
    document.getElementById("num1").style.backgroundColor="lightblue"
    document.getElementById("num2").style.backgroundColor="lightblue"
    document.getElementById("result").style.backgroundColor="lightblue"
    }
    document.getElementById("mul").addEventListener("click",mul);


    
function div(){
    let n1= document.getElementById("num1").value;
    let n2= document.getElementById("num2").value;
    let r=parseInt(n1)/parseInt(n2)
    document.getElementById("result").value=r;
    
    document.getElementById("num1").style.backgroundColor="yellow"
        document.getElementById("num2").style.backgroundColor="yellow"
        document.getElementById("result").style.backgroundColor="yellow"
        }
    
    document.getElementById("div").addEventListener("click",div);



    function e(){
        let n1= document.getElementById("num1").value;
        let n2= document.getElementById("num2").value;
        let r=parseInt(n1)**parseInt(n2)
        document.getElementById("result").value=r;
        
        document.getElementById("num1").style.backgroundColor="lightgreen"
        document.getElementById("num2").style.backgroundColor="lightgreen"
        document.getElementById("result").style.backgroundColor="lightgreen"
        }
        document.getElementById("e").addEventListener("click",e);